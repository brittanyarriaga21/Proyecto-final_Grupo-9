USE futbol;
-- Parte 1: Conociendo la Data (4 preguntas)
-- 1. ¿Cuántas competiciones diferentes existen en la base de datos?
SELECT COUNT(DISTINCT competition_code) AS total_competiciones
FROM competitions;

-- 2. ¿Cuántas temporadas se registran en total?
SELECT COUNT(DISTINCT season_id) AS num_seasons FROM seasons;

-- 3. ¿Cuántos equipos distintos están registrados?
SELECT COUNT(DISTINCT team_id) AS total_equipos
FROM teams;

-- 4. ¿Cuántos árbitros distintos aparecen en los partidos?
SELECT COUNT(DISTINCT referee_id) AS total_arbitros_en_partidos
FROM matches;

-- Parte 2: Consultas de análisis (6 preguntas)
-- 5. ¿Cuál es el equipo con mayor cantidad de partidos jugados como local?

SELECT t.team_name, COUNT(*) AS home_matches
FROM matches m
JOIN teams t ON t.team_id = m.home_team_id
GROUP BY t.team_id, t.team_name
ORDER BY home_matches DESC
LIMIT 1;

-- 6. ¿Cuál es el equipo con mayor cantidad de victorias en total?
SELECT team_name, wins FROM (
  SELECT t.team_name,
    SUM(CASE WHEN m.match_outcome = 'Home Win' AND m.home_team_id = t.team_id THEN 1 ELSE 0 END
      + CASE WHEN m.match_outcome = 'Away Win' AND m.away_team_id = t.team_id THEN 1 ELSE 0 END) AS wins
  FROM teams t
  LEFT JOIN matches m ON t.team_id IN (m.home_team_id, m.away_team_id)
  GROUP BY t.team_id, t.team_name
) x
ORDER BY wins DESC
LIMIT 1;

-- 7. ¿Qué temporada tuvo la mayor cantidad de goles anotados (suma de todos los partidos)?
SELECT s.season, SUM(m.total_goals) AS total_goles
FROM seasons s
JOIN matches m ON s.season_id = m.season_id
GROUP BY s.season
ORDER BY total_goles DESC
LIMIT 1;

-- 8. ¿Cuál es la diferencia promedio de goles por competición?

SELECT c.competition_name, AVG(m.goal_difference) AS promedio_diferencia_goles
FROM competitions c
JOIN seasons s ON c.competition_code = s.competition_code
JOIN matches m ON s.season_id = m.season_id
GROUP BY c.competition_name
ORDER BY promedio_diferencia_goles DESC;

-- 9. ¿Qué árbitro ha dirigido la mayor cantidad de partidos?

SELECT r.referee, COUNT(*) AS matches_count
FROM matches m
JOIN referees r ON r.referee_id = m.referee_id
GROUP BY r.referee_id, r.referee
ORDER BY matches_count DESC
LIMIT 1;

-- 10. ¿Qué equipo tiene un mejor promedio de goles anotados por partido en la Bundesliga?

WITH bl1_seasons AS (
  SELECT season_id FROM seasons WHERE competition_code = 'BL1'
),
bl1_matches AS (
  SELECT * FROM matches WHERE season_id IN (SELECT season_id FROM bl1_seasons)
),
team_goals AS (
  SELECT home_team_id AS team_id, AVG(fulltime_home) AS avg_goles
  FROM bl1_matches GROUP BY home_team_id
  UNION ALL
  SELECT away_team_id AS team_id, AVG(fulltime_away) AS avg_goles
  FROM bl1_matches GROUP BY away_team_id
),
team_avg AS (
  SELECT team_id, AVG(avg_goles) AS overall_avg
  FROM team_goals GROUP BY team_id
)
SELECT t.team_name, ta.overall_avg
FROM team_avg ta
JOIN teams t ON t.team_id = ta.team_id
ORDER BY ta.overall_avg DESC
LIMIT 1;


-- Preguntas propias
-- 1 ¿Cuántos partidos terminaron con más de 5 goles en total por competición?
SELECT c.competition_name, COUNT(m.match_id) AS partidos_mas_5_goles
FROM competitions c
JOIN seasons s ON c.competition_code = s.competition_code
JOIN matches m ON s.season_id = m.season_id
WHERE m.total_goals > 5
GROUP BY c.competition_name
ORDER BY partidos_mas_5_goles DESC;

-- 2.¿Cuáles son los 10 equipos con el mayor promedio de puntos obtenidos como visitante?
SELECT t.team_name, AVG(m.away_points) AS promedio_puntos_visitante
FROM teams t
JOIN matches m ON t.team_id = m.away_team_id
GROUP BY t.team_name
ORDER BY promedio_puntos_visitante DESC
LIMIT 10;

-- 3 ¿Cómo evolucionan los goles promedio por jornada (matchday) en la Premier League?
SELECT m.matchday, 
       AVG(m.total_goals) AS avg_goals
FROM matches m
JOIN seasons s ON s.season_id = m.season_id
WHERE s.competition_code = 'PL'
GROUP BY m.matchday
ORDER BY m.matchday; 	

-- 4 ¿Cuál fue el partido con mayor diferencia de goles registrado?
SELECT m.match_id, c.competition_name, s.season AS season_name, 
       t1.team_name AS local, t2.team_name AS visitante,
       m.fulltime_home AS home_goals, m.fulltime_away AS away_goals,
       ABS(m.fulltime_home - m.fulltime_away) AS diferencia
FROM matches m
JOIN teams t1 ON m.home_team_id = t1.team_id
JOIN teams t2 ON m.away_team_id = t2.team_id
JOIN seasons s ON m.season_id = s.season_id
JOIN competitions c ON s.competition_code = c.competition_code
ORDER BY diferencia DESC
LIMIT 1;

-- 5 ¿Cuáles son los 5 equipos con más empates en la historia de la base de datos?
SELECT t.team_name, SUM(empates) AS total_empates
FROM (
    -- Empates como local
    SELECT m.home_team_id AS team_id,
           COUNT(*) AS empates
    FROM matches m
    WHERE m.match_outcome = 'Draw'
    GROUP BY m.home_team_id
    
    UNION ALL

    -- Empates como visitante
    SELECT m.away_team_id AS team_id,
           COUNT(*) AS empates
    FROM matches m
    WHERE m.match_outcome = 'Draw'
    GROUP BY m.away_team_id
) empates_por_equipo
JOIN teams t ON empates_por_equipo.team_id = t.team_id
GROUP BY t.team_id, t.team_name
ORDER BY total_empates DESC
LIMIT 5;